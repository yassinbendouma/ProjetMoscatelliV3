package fr.hellocorp.projetmoscatelli;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetMoscatelliApplicationTests {

    @Test
    void contextLoads() {
    }

}
