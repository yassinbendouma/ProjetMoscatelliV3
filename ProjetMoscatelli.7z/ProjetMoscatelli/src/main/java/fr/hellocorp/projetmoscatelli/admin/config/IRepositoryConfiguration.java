package fr.hellocorp.projetmoscatelli.admin.config;

import org.springframework.data.repository.CrudRepository;

public interface IRepositoryConfiguration extends CrudRepository< Configuration, Long> {

}
